﻿//------------------------------------------------------------------------------
// <copyright file="MainWindow.xaml.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Data;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace Microsoft.Samples.Kinect.BodyBasics
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Windows;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using Microsoft.Kinect;

    /// <summary>
    /// 在主窗口的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// 手圈半径
        /// </summary>
        private const double HandSize = 30;
        double qianhou = 0, zuoyou = 0, shangxia = 0;//原始数据
        int qianhou_int = 0, zuoyou_int = 0, shangxia_int = 0;//转int后的数据

        int[] buflb=new int[21];
        int[] buflb2 = new int[61];
        int[] buflb3 = new int[21];
        int[] buflb4 = new int[21];

        float zuoyou_buf = 0;
        float shangxia_buf = 0;
        float qianhou_buf = 0;

        float buf_2 = 0;
        float buf_3 = 0;
        float buf_4 = 0;
        int i = 0, i2 = 0, i3 = 0;



        int r = 0;//传感器检测不到手避免机械臂出现误动作

        string qianhou_ascii="0", zuoyou_ascii="0", shangxia_ascii="0";//转string从串口发送出去
        
        int shou = 1; //手掌是张开还是握紧，0为握紧，1为张开或半张
        int rx_ok = 1;//串口接收判断
                      // float q1=0, h1=0,sx=0;
        float shuju = 0;

        int max = 0, min = 500;

        /// <summary>
        /// 相机空间的夹紧z值为负值。
        /// </summary>
        private const float InferredZPositionClamp = 0.1f;

        /// <summary>
        /// 用于绘制当前闭合的手的刷子。
        /// </summary>
        private readonly Brush handClosedBrush = new SolidColorBrush(Color.FromArgb(128, 255, 0, 0));

        /// <summary>
        /// 用于绘制当前被打开的手的刷子。
        /// </summary>
        private readonly Brush handOpenBrush = new SolidColorBrush(Color.FromArgb(128, 0, 255, 0));

        /// <summary>
        /// 用于绘制当前在套索（指针）位置上跟踪的手的刷子。
        /// </summary>
        private readonly Brush handLassoBrush = new SolidColorBrush(Color.FromArgb(128, 0, 0, 255));

        /// <summary>
        /// 用于绘制当前跟踪的接头的刷子。
        /// </summary>
        private readonly Brush trackedJointBrush = new SolidColorBrush(Color.FromArgb(255, 68, 192, 68));

        /// <summary>
        /// 用于绘制当前推断的节理的刷子。
        /// </summary>        
        private readonly Brush inferredJointBrush = Brushes.Yellow;

        /// <summary>
        /// 用于绘制目前推断出的骨骼的笔
        /// </summary>        
        private readonly Pen inferredBonePen = new Pen(Brushes.Gray, 1);

        /// <summary>
        /// 体绘制输出绘图组
        /// </summary>
        private DrawingGroup drawingGroup;

        /// <summary>
        /// 绘制将显示的图像
        /// </summary>
        private DrawingImage imageSource;

        /// <summary>
        /// 活跃的Kinect传感器
        /// </summary>
        private KinectSensor kinectSensor = null;

        /// <summary>
        /// 坐标映射器将一种点映射到另一种类型
        /// </summary>
        private CoordinateMapper coordinateMapper = null;

        /// <summary>
        /// 身体框架阅读器
        /// </summary>
        private BodyFrameReader bodyFrameReader = null;

        /// <summary>
        /// 物体阵列
        /// </summary>
        private Body[] bodies = null;


        /// <summary>
        /// 显示宽度（深度空间）
        /// </summary>
        private int displayWidth;

        /// <summary>
        /// 显示器高度（深度空间）
        /// </summary>
        private int displayHeight;

        /// <summary>
        /// 流到显示状态文本
        /// </summary>
        private string statusText = null;

        /// <summary>
        /// 初始化主窗口类的一个新实例。
        /// </summary>
        public MainWindow()
        {
            
            // 目前支持一个传感器。
            this.kinectSensor = KinectSensor.GetDefault();

            // 获取坐标映射器
            this.coordinateMapper = this.kinectSensor.CoordinateMapper;

            // 获取深度（显示）范围
            FrameDescription frameDescription = this.kinectSensor.DepthFrameSource.FrameDescription;

            // 获得关节空间大小
            this.displayWidth = frameDescription.Width;
            this.displayHeight = frameDescription.Height;

            // 定义身体框架抓取器
            this.bodyFrameReader = this.kinectSensor.BodyFrameSource.OpenReader();

      

            // 打开传感器
            this.kinectSensor.Open();

            // 设置状态文本
            this.StatusText = this.kinectSensor.IsAvailable ? Properties.Resources.RunningStatusText
                                                            : Properties.Resources.NoSensorStatusText;

            // 创建我们将用于绘图的绘图组
            this.drawingGroup = new DrawingGroup();

            // 创建一个可以在图像控制中使用的图像源
            this.imageSource = new DrawingImage(this.drawingGroup);

            //在这个简单的例子中使用窗口对象作为视图模型
            this.DataContext = this;

            //初始化窗口的组件（控件）
            this.InitializeComponent();
            OpenSerialPort();

        }

        /********************************************************************************************************/
        delegate void HanderInterfaceUpdataDelegate(string mySendData);
        HanderInterfaceUpdataDelegate myUpdataHander;
        delegate void txtGotoEndDelegate();

        SerialPort mySerialPort = new SerialPort();
        string[] portsName = SerialPort.GetPortNames();
        //串口关闭标志
        bool serialportIsClosing;
        /// <summary>
        /// inotifypropertychangedpropertychanged事件让窗口控件绑定到可变数据
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            

            OpenSerialPort();

           // LoadDataGrid();

            //dg.ItemsSource = dt.DefaultView;
        }
        private void OpenSerialPort()
        {
            if (mySerialPort.IsOpen)
            {
                mySerialPort.Close();
            }
            else
            {
                if (portsName.Length > 0)
                {
                    Array.Sort(portsName);
                    mySerialPort.PortName = portsName[0];
                    mySerialPort.DataBits = 8;
                    mySerialPort.BaudRate = 115200;
                    mySerialPort.Parity = Parity.None;
                    mySerialPort.StopBits = StopBits.One;
                    try
                    {
                        mySerialPort.Open();
                    }
                    catch
                    {
                        MessageBox.Show("串口被占用！");
                        return;
                    }
                }
            }
        }
        private void CloseSerialPort()
        {
            serialportIsClosing = true;
            //serialportIsClosing为true后，mySerialPort_DataReceived就不会在接收数据
            //等待个20毫秒，以确保不再接收，在关闭串口
            //否则，如果频繁点击打开/关闭 串口还在接收数据就关闭串口会出现界面卡死
            Thread.Sleep(10);
            if (mySerialPort.IsOpen)
            {
                mySerialPort.Close();

            }
            else
            {
                MessageBox.Show("串口已关闭");
            }
        }
        //串口接收函数
        private void mySerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            //如果串口正在关闭，返回
            if (serialportIsClosing == true)
            {
                return;
            }
            int n = mySerialPort.BytesToRead;
            byte[] buf = new byte[n];
            mySerialPort.Read(buf, 0, n);
            myUpdataHander = new HanderInterfaceUpdataDelegate(getData);
            string abc;
            //abc为接收到的16进制字符串
            abc = System.Text.Encoding.Default.GetString(buf);
            if (abc == "$0 OK")
            {
                rx_ok = 1;
            }
            Dispatcher.Invoke(myUpdataHander, abc);
        }
        private void getData(string sendData)
        {
           // MessageBox.Show(sendData);
        }
    

        private void btSend_Event(string strSend)//发送数据
        {
           
                if (rx_ok == 1)
                {
                    if (mySerialPort.IsOpen)
                    {
                        byte[] sendHexData = Encoding.ASCII.GetBytes(strSend);

                        mySerialPort.Write(sendHexData, 0, sendHexData.Length);
                        r = 0;
                    }
                    else
                    {
                        MessageBox.Show("串口没有打开，请检查！");
                    }
                }
        }
        private void btSend_Click(object sender, RoutedEventArgs e)//发送按钮
        {
            btSend_Event("#n M231 V1\n");//发送按钮
            MessageBox.Show("触发");
        }

        /************************************************************************************************************************************************/
        /// <summary>
        /// 获取要显示的位图。
        /// </summary>
        public ImageSource ImageSource
        {
            get
            {
                return this.imageSource;
            }
        }

        /// <summary>
        /// 获取或设置要显示的当前状态文本。
        /// </summary>
        public string StatusText
        {
            get
            {
                return this.statusText;
            }

            set
            {
                if (this.statusText != value)
                {
                    this.statusText = value;

                    // 通知文本已更改的任何绑定元素。
                    if (this.PropertyChanged != null)
                    {
                        this.PropertyChanged(this, new PropertyChangedEventArgs("StatusText"));
                    }
                }
            }
        }

        /// <summary>
        /// 执行启动任务
        /// </summary>
        /// <param name="sender">发送事件的对象</param>
        /// <param name="e">事件参数</param>
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.bodyFrameReader != null)
            {
                this.bodyFrameReader.FrameArrived += this.Reader_FrameArrived;
            }
        }

        /// <summary>
        /// 执行关机任务
        /// </summary>
        /// <param name="sender">发送事件的对象</param>
        /// <param name="e">事件参数</param>
        private void MainWindow_Closing(object sender, CancelEventArgs e)
        {
            if (this.bodyFrameReader != null)
            {
                // BodyFrameReader是IDisposable
                this.bodyFrameReader.Dispose();
                this.bodyFrameReader = null;
            }

            if (this.kinectSensor != null)
            {
                this.kinectSensor.Close();
                this.kinectSensor = null;
            }
        }

        /// <summary>
        /// 处理从传感器到达的身体帧数据。
        /// </summary>
        /// <param name="sender">发送事件的对象</param>
        /// <param name="e">事件参数</param>
        private void Reader_FrameArrived(object sender, BodyFrameArrivedEventArgs e)
        {
            bool dataReceived = false;
            
            using (BodyFrame bodyFrame = e.FrameReference.AcquireFrame())
            {
                if (bodyFrame != null)
                {
                    if (this.bodies == null)
                    {
                        this.bodies = new Body[bodyFrame.BodyCount];
                    }

                    //第一次getandrefreshbodydata称，Kinect将数组中的每个体分配。
                    //只要这些体对象没有被处理，数组中没有设置为null，
                    //这些物体将被重新使用。
                    bodyFrame.GetAndRefreshBodyData(this.bodies);
                    dataReceived = true;
                }
            }

            if (dataReceived)
            {
                using (DrawingContext dc = this.drawingGroup.Open())
                {
                    //绘制透明背景以设置渲染大小。
                    dc.DrawRectangle(Brushes.Black, null, new Rect(0.0, 0.0, this.displayWidth, this.displayHeight));

                    foreach (Body body in this.bodies)
                    {
                     

                        if (body.IsTracked)
                        {

                            IReadOnlyDictionary<JointType, Joint> joints = body.Joints;

                            // 将关节点转换为深度（显示）空间
                            Dictionary<JointType, Point> jointPoints = new Dictionary<JointType, Point>();

                            foreach (JointType jointType in joints.Keys)
                            {
                                //有时推断出的关节深度（z）可能表现为阴性。
                                // 夹到0.1F至防止coordinatemapper返回（∞，∞）
                                CameraSpacePoint position = joints[jointType].Position;
                                if (position.Z < 0)
                                {
                                    position.Z = InferredZPositionClamp;
                                }
                                qianhou = position.Z;//获取Z轴作为前后移动
                                DepthSpacePoint depthSpacePoint = this.coordinateMapper.MapCameraPointToDepthSpace(position);
                                jointPoints[jointType] = new Point(depthSpacePoint.X, depthSpacePoint.Y);
                                shangxia = depthSpacePoint.Y;//获取Y轴数据左右上下移动

                                zuoyou = depthSpacePoint.X;//获取X轴数据作为左右移动

                                
                            }
                            if (r == 1)//捕捉到手证明数据有效，进行计算发送到机械手上
                            {
                                qianhou_int = (int)(qianhou * 100);//Z轴数据放大100倍
                                zuoyou_int = (int)zuoyou;//强制转换为int类型
                                shangxia_int = (int)shangxia;//强制转换为int类型

    /*********************************************************前后数据计算********************************************************************/

                                if (qianhou_int < 110) qianhou_int = 110;//软件界面手的捕获范围的最小值
                                if (qianhou_int > 180) qianhou_int = 180;//软件界面手的捕获范围的最大值
                                qianhou_int -= 90;//前后最小值是30，所以要减去90
                                qianhou_int += (int)((double)qianhou_int * 0.8);//运动轨迹放大

                                buf_2 = 0;//滤波结果清空

                                buflb[i++] = qianhou_int;//将最新值放入数组中
                                for (i = 0; i < 20; i++)//将数组中的元素全部向前移动一位，将最新值放到最尾
                                {
                                    buflb[i] = buflb[i + 1];
                                    buf_2 += buflb[i];//将所有值做一个平均计算
                                }
                                buf_2 /= 20;
                                if (qianhou_buf < buf_2) if ((buf_2 - qianhou_buf) >= 2) qianhou_buf += 2;
                                if (qianhou_buf > buf_2) if ((qianhou_buf - buf_2) >= 2) qianhou_buf -= 2;
                               
                                qianhou_ascii =qianhou_buf.ToString();//将结果转换成字符串数据

/*********************************************************左右数据计算***************************************************************************/


                                if (zuoyou_int <= 200) zuoyou_int = 200;
                                if (zuoyou_int >= 380) zuoyou_int = 380;
                                zuoyou_int -= 200;

                                //zuoyou_int= (int)((double)(zuoyou_int * 0.69));

                                buf_3 = 0;
                                buflb2[i2++] = zuoyou_int;
                                for (i2 = 0; i2 < 20; i2++)
                                {
                                    buflb2[i2] = buflb2[i2 + 1];
                                    buf_3 += buflb2[i2];
                                }
                                buf_3 /= 20;
                                if (buf_3 > 180) buf_3 = 180;
                                buf_3 = 180 - buf_3;
                                buf_3 = (int)buf_3;
                                
                                if (zuoyou_buf > buf_3)if((zuoyou_buf-buf_3)>=2) zuoyou_buf-=2;
                                if (zuoyou_buf < buf_3)if((buf_3-zuoyou_buf)>=2) zuoyou_buf+=2;
                                zuoyou_buf = (int)zuoyou_buf;
                                zuoyou_ascii = zuoyou_buf.ToString();

/****************************************************上下数据计算********************************************************************************/

                                if (shangxia_int <= 140) shangxia_int = 140;//软件捕获范围
                                if (shangxia_int >= 220) shangxia_int = 220;
                                shangxia_int -= 110;//上下数值最低是30，所以减去100
                                buf_4 = 0;//滤波值清空
                                buflb3[i3++] = shangxia_int;//存入最新值
                                for (i3 = 0; i3 < 20; i3++)
                                {
                                    buflb3[i3] = buflb3[i3 + 1];
                                    buf_4 += buflb3[i3];//求和
                                } 
                                buf_4 /= 20;//求平均

                                if (shangxia_buf < buf_4) if ((buf_4 - shangxia_buf) >= 2) shangxia_buf += 2;
                                if (shangxia_buf > buf_4) if ((shangxia_buf - buf_4) >= 2) shangxia_buf -= 2;
                                shangxia_ascii = shangxia_buf.ToString();//将结果转换为字符串数据
                               
                                
                                if ( buf_4 > 0)
                                {
                                    //防止吸头低于水平位置，经过数学统计后得出M1\M2坐标斜率比为大于0.53小于3.5
                                    if ((buf_2 / buf_4) >= 0.53&& (buf_2 / buf_4) <= 3.5)
                                    {
                                        
                                        btSend_Event("#n G202 N1 V");
                                        btSend_Event(qianhou_ascii);
                                        btSend_Event("\n");
                                        btSend_Event("#n G202 N2 V");
                                        btSend_Event(shangxia_ascii);
                                        btSend_Event("\n");
                                        btSend_Event("#n G202 N0 V");
                                        btSend_Event(zuoyou_ascii);
                                        btSend_Event("\n");


                                        shuju = buf_2 / buf_4;
                                    
                                    //rxtext.Text = shuju.ToString()+"   "+zuoyou_ascii/*+"     "+shangxia_ascii+"        "+buf_2.ToString()+"    "+buf_4.ToString()*/;
                               
                                   }
                                }
                                    
                                    
                                   if (shou == 0) btSend_Event("#n M231 V1\n"); //手握紧
                                   if (shou == 1) btSend_Event("#n M231 V0\n");//手张开或半开
                                   r = 0;
                            }
         
                            this.DrawHand(body.HandLeftState, jointPoints[JointType.HandLeft], dc);
                            this.DrawHand(body.HandRightState, jointPoints[JointType.HandRight], dc);
                            
                        }
                    }

                    // 防止在我们的渲染区域之外绘制
                    this.drawingGroup.ClipGeometry = new RectangleGeometry(new Rect(0.0, 0.0, this.displayWidth, this.displayHeight));
                }
            }     
        }

        /// <summary>
        /// 如果手被跟踪，画一个手符号：红色圆圈=封闭，绿色圆圈=打开；蓝色圆圈=套索
        /// </summary>
        /// <param name="handState">state of the hand</param>
        /// <param name="handPosition">position of the hand</param>
        /// <param name="drawingContext">drawing context to draw to</param>
        private void DrawHand(HandState handState, Point handPosition, DrawingContext drawingContext)
        {

            switch (handState)
            {
                case HandState.Closed:
                    drawingContext.DrawEllipse(this.handClosedBrush, null, handPosition, qianhou*20, qianhou * 20);
                    shou = 0;//手放开闭合状态保存
                    r = 1;//捕捉到手
                    break;

                case HandState.Open:
                    drawingContext.DrawEllipse(this.handOpenBrush, null, handPosition, qianhou * 20, qianhou * 20);
                    shou = 1;//手放开闭合状态保存
                    r = 1;//捕捉到手
                    break;

                case HandState.Lasso:
                    drawingContext.DrawEllipse(this.handLassoBrush, null, handPosition, qianhou * 20, qianhou * 20);
                    shou = 1;//手放开闭合状态保存
                    r = 0;//捕捉到手
                    break;
            }
        }

     
    }
}
